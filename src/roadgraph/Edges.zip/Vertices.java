package roadgraph;

import java.util.ArrayList;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.List;

import geography.GeographicPoint;

class Vertices {

	
	private GeographicPoint coord;
	List <Edges> edges;
	
	Vertices(GeographicPoint coord) {
		this.coord = coord;
		edges = new ArrayList<Edges>();
	}
	
	public static void getCoord (Vertices coord) {
		System.out.println(coord.coord.getX() + "|" + coord.coord.getY());
		
	}
	
	public GeographicPoint getGeoPoint() {
		return this.coord;
	}
	
	
	
	
}
